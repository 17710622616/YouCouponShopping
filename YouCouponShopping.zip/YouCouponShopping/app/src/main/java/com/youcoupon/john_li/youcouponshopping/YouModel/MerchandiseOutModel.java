package com.youcoupon.john_li.youcouponshopping.YouModel;

import java.util.List;

/**
 * Created by John_Li on 30/5/2018.
 */

public class MerchandiseOutModel {

    /**
     * tbk_uatm_favorites_item_get_response : {"results":{"uatm_tbk_item":[{"category":16,"click_url":"https://s.click.taobao.com/t?e=m%3D2%26s%3D9eXo1%2B4wb0xw4vFB6t2Z2ueEDrYVVa64XoO8tOebS%2Bfjf2vlNIV67nKx%2F0WMtCwsjGYPrSmetxH9VCSQqTLsa4%2BDpQeWfDJaVpEUn89CVjnJsAA91U3vce%2FBas0tvb4eZz42eVlqqJT6BXppXS5x5z0BDlc5vrJjopr%2FSerwmYPPQZX9jO9tUbYtcWZSGtno5Zhxu%2BbPYAutNnoIVcZmJueY5tUZuWkpxgxdTc00KD8%3D","coupon_click_url":"https://uland.taobao.com/coupon/edetail?e=n7qaPzoNPcAGQASttHIRqQkZPCfQqsO4V1yHWHmoq9WPr5ljijO76C2hIi8KRT8qiiDmULtsMvCJI6EXzi0xFL9fwBwwUiqlCfDTD%2F74gDLJnadaiBmiH%2FSs4zOlZ4se","coupon_end_time":"2018-06-30","coupon_info":"满100元减10元","coupon_remain_count":98688,"coupon_start_time":"2018-05-26","coupon_total_count":100000,"event_end_time":"1970-01-01 00:00:00","event_start_time":"1970-01-01 00:00:00","item_url":"http://h5.m.taobao.com/awp/core/detail.htm?id=569092747231","nick":"du嘟嘟家","num_iid":569092747231,"pict_url":"https://img.alicdn.com/tfscom/i4/450662946/TB2FCOfhsyYBuNkSnfoXXcWgVXa_!!450662946.jpg","provcity":"广东 广州","reserve_price":"109.80","seller_id":450662946,"shop_title":"嘟嘟家 酷风来袭","small_images":{"string":["https://img.alicdn.com/tfscom/i2/450662946/TB2WV.dpL1TBuNjy0FjXXajyXXa_!!450662946.jpg","https://img.alicdn.com/tfscom/i3/450662946/TB2toDQpH1YBuNjSszhXXcUsFXa_!!450662946.jpg","https://img.alicdn.com/tfscom/i4/450662946/TB2j6T2pQCWBuNjy0FaXXXUlXXa_!!450662946.jpg","https://img.alicdn.com/tfscom/i2/450662946/TB2FuGihOOYBuNjSsD4XXbSkFXa_!!450662946.jpg"]},"status":1,"title":"半身牛仔裙女2018新款夏季韩版宽松百搭学生BF风潮ins超火的裙子","tk_rate":"5.00","type":1,"user_type":0,"volume":89,"zk_final_price":"109.80","zk_final_price_wap":"109.80"},{"category":16,"click_url":"https://s.click.taobao.com/t?e=m%3D2%26s%3D1pgEMyGO8blw4vFB6t2Z2ueEDrYVVa64XoO8tOebS%2Bfjf2vlNIV67nKx%2F0WMtCwsjGYPrSmetxH9VCSQqTLsa4%2BDpQeWfDJaVpEUn89CVjnJsAA91U3vce%2FBas0tvb4eZz42eVlqqJT6BXppXS5x5z0BDlc5vrJjopr%2FSerwmYM1LTXXCD%2BOUvsQkLppJOqGUgJOt%2FgUtXY4GU9PM8GyritwjvUPA%2BzkcSpj5qSCmbA%3D","coupon_click_url":"https://uland.taobao.com/coupon/edetail?e=axaQcZXDXDAGQASttHIRqelATBH1eoytSuNX%2F0cyFv6Pr5ljijO76C2hIi8KRT8qiiDmULtsMvCJI6EXzi0xFL9fwBwwUiqlCfDTD%2F74gDLJnadaiBmiH%2FSs4zOlZ4se","coupon_end_time":"2018-05-30","coupon_info":"满200元减30元","coupon_remain_count":2150,"coupon_start_time":"2018-05-24","coupon_total_count":5000,"event_end_time":"1970-01-01 00:00:00","event_start_time":"1970-01-01 00:00:00","item_url":"http://h5.m.taobao.com/awp/core/detail.htm?id=569079538463","nick":"yueliang1985415","num_iid":569079538463,"pict_url":"https://img.alicdn.com/tfscom/i2/TB1M0zRpv9TBuNjy1zbYXFpepXa_M2.SS2","provcity":"广东 深圳","reserve_price":"538.00","seller_id":87253698,"shop_title":"s秀名媛馆 高端女装","small_images":{"string":["https://img.alicdn.com/tfscom/i1/TB1PfxfpStYBeNjSspkYXHU8VXa_M2.SS2","https://img.alicdn.com/tfscom/i7/TB1ptDRpv9TBuNjy1zbYXFpepXa_M2.SS2","https://img.alicdn.com/tfscom/i7/TB1QQ6XpwmTBuNjy1XbYXGMrVXa_M2.SS2","https://img.alicdn.com/tfscom/i3/TB1e1bQpv5TBuNjSspcYXHnGFXa_M2.SS2"]},"status":1,"title":"s秀2018夏女新款时尚港风ins超火T恤中长款蓬蓬网纱裙套装两件套","tk_rate":"15.00","type":1,"user_type":0,"volume":9,"zk_final_price":"269.00","zk_final_price_wap":"269.00"},{"category":16,"click_url":"https://s.click.taobao.com/t?e=m%3D2%26s%3Di%2FBrGRTeS91w4vFB6t2Z2ueEDrYVVa64XoO8tOebS%2Bfjf2vlNIV67nKx%2F0WMtCwsjGYPrSmetxH9VCSQqTLsa4%2BDpQeWfDJaVpEUn89CVjnJsAA91U3vce%2FBas0tvb4eZz42eVlqqJT6BXppXS5x5z0BDlc5vrJjopr%2FSerwmYOsSowblonTuNBI2Mmq9AhlJIVU%2B7iDh6VxwM1syVBzrB9hW2JKu7YsDJbuZDCrHt4%3D","coupon_click_url":"https://uland.taobao.com/coupon/edetail?e=BFcTFUzIkqMGQASttHIRqbWqjL2%2FMu%2BcS85%2BAekcBQyPr5ljijO76C2hIi8KRT8qiiDmULtsMvCJI6EXzi0xFL9fwBwwUiqlCfDTD%2F74gDLJnadaiBmiH%2FSs4zOlZ4se","coupon_end_time":"2018-05-31","coupon_info":"满100元减10元","coupon_remain_count":9211,"coupon_start_time":"2018-05-28","coupon_total_count":10000,"event_end_time":"1970-01-01 00:00:00","event_start_time":"1970-01-01 00:00:00","item_url":"http://h5.m.taobao.com/awp/core/detail.htm?id=569600285991","nick":"ericsha0007","num_iid":569600285991,"pict_url":"https://img.alicdn.com/tfscom/i3/2904804747/TB2xD5afOMnBKNjSZFzXXc_qVXa_!!2904804747.jpg","provcity":"北京","reserve_price":"219.00","seller_id":2904804747,"shop_title":"胡月明 AMARIS HOO","small_images":{"string":["https://img.alicdn.com/tfscom/i4/2904804747/TB2.ieyi98YBeNkSnb4XXaevFXa_!!2904804747.jpg","https://img.alicdn.com/tfscom/i3/2904804747/TB2pB6OrbSYBuNjSspfXXcZCpXa_!!2904804747.jpg","https://img.alicdn.com/tfscom/i3/2904804747/TB28dnBrb9YBuNjy0FgXXcxcXXa_!!2904804747.jpg","https://img.alicdn.com/tfscom/i2/2904804747/TB24R_Wrf1TBuNjy0FjXXajyXXa_!!2904804747.jpg"]},"status":1,"title":"大月月定制 连衣裙女夏2018新款露肩显瘦雪纺中长款ins超火的裙子","tk_rate":"5.00","type":1,"user_type":0,"volume":124,"zk_final_price":"169.00","zk_final_price_wap":"169.00"},{"category":16,"click_url":"https://s.click.taobao.com/t?e=m%3D2%26s%3Dy1u4cF%2FNJaVw4vFB6t2Z2ueEDrYVVa64yK8Cckff7TXjf2vlNIV67nKx%2F0WMtCwsjGYPrSmetxH9VCSQqTLsa4%2BDpQeWfDJaVpEUn89CVjnJsAA91U3vce%2FBas0tvb4eZz42eVlqqJT6BXppXS5x5z0BDlc5vrJjopr%2FSerwmYPdauuLewEf2KoSINHC3AbXjMTCuk80ROq0G5roL0JvhR9hW2JKu7YsDJbuZDCrHt4%3D","coupon_click_url":"https://uland.taobao.com/coupon/edetail?e=NwKW9uiRK4cGQASttHIRqfrywtHuKwTXzTlmBU7yF6GPr5ljijO76C2hIi8KRT8qiiDmULtsMvCJI6EXzi0xFL9fwBwwUiqlCfDTD%2F74gDLJnadaiBmiH%2FSs4zOlZ4se","coupon_end_time":"2018-06-10","coupon_info":"满99元减10元","coupon_remain_count":99720,"coupon_start_time":"2018-05-29","coupon_total_count":100000,"event_end_time":"1970-01-01 00:00:00","event_start_time":"1970-01-01 00:00:00","item_url":"http://h5.m.taobao.com/awp/core/detail.htm?id=564944086098","nick":"韩都衣舍敏丽专卖店","num_iid":564944086098,"pict_url":"https://img.alicdn.com/tfscom/i4/1111900536/TB1iBEQt1uSBuNjSsplXXbe8pXa_!!0-item_pic.jpg","provcity":"山东 济南","reserve_price":"288.00","seller_id":1111900536,"shop_title":"韩都衣舍敏丽专卖店","small_images":{"string":["https://img.alicdn.com/tfscom/i4/263817957/TB2hdpbXiQnBKNjSZFmXXcApVXa-263817957.jpg","https://img.alicdn.com/tfscom/i1/263817957/TB2jvBbXbZnBKNjSZFKXXcGOVXa-263817957.jpg","https://img.alicdn.com/tfscom/i1/263817957/TB2gWlWXiCYBuNkSnaVXXcMsVXa-263817957.jpg","https://img.alicdn.com/tfscom/i2/263817957/TB24grdXbSYBuNjSspiXXXNzpXa-263817957.jpg"]},"status":1,"title":"韩都衣舍2018女装夏装条纹收腰气质小清新短款美美的夏夏连衣裙","tk_rate":"6.51","type":1,"user_type":1,"volume":6,"zk_final_price":"165.00","zk_final_price_wap":"165.00"},{"category":16,"click_url":"https://s.click.taobao.com/t?e=m%3D2%26s%3Dprj2C0SXqqpw4vFB6t2Z2ueEDrYVVa64XoO8tOebS%2Bfjf2vlNIV67nKx%2F0WMtCwsjGYPrSmetxH9VCSQqTLsa4%2BDpQeWfDJaVpEUn89CVjnJsAA91U3vce%2FBas0tvb4eZz42eVlqqJT6BXppXS5x5z0BDlc5vrJjopr%2FSerwmYOCMHtpFwM8vWOcw86FTGy78rZl6sW6CV5IJ6G0ZTXBaytwjvUPA%2BzkcSpj5qSCmbA%3D","event_end_time":"1970-01-01 00:00:00","event_start_time":"1970-01-01 00:00:00","item_url":"http://h5.m.taobao.com/awp/core/detail.htm?id=565152848615","nick":"fengshengj","num_iid":565152848615,"pict_url":"https://img.alicdn.com/tfscom/i4/90489528/TB1_KncbuuSBuNjSsplXXbe8pXa_!!0-item_pic.jpg","provcity":"浙江 杭州","reserve_price":"299.00","seller_id":90489528,"shop_title":"日着設計師服飾品牌","small_images":{"string":["https://img.alicdn.com/tfscom/i4/90489528/TB2mKrcbuuSBuNjSsplXXbe8pXa_!!90489528.jpg","https://img.alicdn.com/tfscom/i4/90489528/TB2tOLpbv1TBuNjy0FjXXajyXXa_!!90489528.jpg","https://img.alicdn.com/tfscom/i3/90489528/TB2CsPmbpuWBuNjSspnXXX1NVXa_!!90489528.jpg","https://img.alicdn.com/tfscom/i4/90489528/TB2l92ebxSYBuNjSsphXXbGvVXa_!!90489528.jpg"]},"status":1,"title":"日着原创设计女装【你是407吗】2018夏季新款宽松不对称解构T恤","tk_rate":"5.00","type":1,"user_type":0,"volume":98,"zk_final_price":"299.00","zk_final_price_wap":"299.00"}]},"total_results":5,"request_id":"10fk4ls6lekjw"}
     */

    private TbkUatmFavoritesItemGetResponseBean tbk_uatm_favorites_item_get_response;

    public TbkUatmFavoritesItemGetResponseBean getTbk_uatm_favorites_item_get_response() {
        return tbk_uatm_favorites_item_get_response;
    }

    public void setTbk_uatm_favorites_item_get_response(TbkUatmFavoritesItemGetResponseBean tbk_uatm_favorites_item_get_response) {
        this.tbk_uatm_favorites_item_get_response = tbk_uatm_favorites_item_get_response;
    }

    public static class TbkUatmFavoritesItemGetResponseBean {
        /**
         * results : {"uatm_tbk_item":[{"category":16,"click_url":"https://s.click.taobao.com/t?e=m%3D2%26s%3D9eXo1%2B4wb0xw4vFB6t2Z2ueEDrYVVa64XoO8tOebS%2Bfjf2vlNIV67nKx%2F0WMtCwsjGYPrSmetxH9VCSQqTLsa4%2BDpQeWfDJaVpEUn89CVjnJsAA91U3vce%2FBas0tvb4eZz42eVlqqJT6BXppXS5x5z0BDlc5vrJjopr%2FSerwmYPPQZX9jO9tUbYtcWZSGtno5Zhxu%2BbPYAutNnoIVcZmJueY5tUZuWkpxgxdTc00KD8%3D","coupon_click_url":"https://uland.taobao.com/coupon/edetail?e=n7qaPzoNPcAGQASttHIRqQkZPCfQqsO4V1yHWHmoq9WPr5ljijO76C2hIi8KRT8qiiDmULtsMvCJI6EXzi0xFL9fwBwwUiqlCfDTD%2F74gDLJnadaiBmiH%2FSs4zOlZ4se","coupon_end_time":"2018-06-30","coupon_info":"满100元减10元","coupon_remain_count":98688,"coupon_start_time":"2018-05-26","coupon_total_count":100000,"event_end_time":"1970-01-01 00:00:00","event_start_time":"1970-01-01 00:00:00","item_url":"http://h5.m.taobao.com/awp/core/detail.htm?id=569092747231","nick":"du嘟嘟家","num_iid":569092747231,"pict_url":"https://img.alicdn.com/tfscom/i4/450662946/TB2FCOfhsyYBuNkSnfoXXcWgVXa_!!450662946.jpg","provcity":"广东 广州","reserve_price":"109.80","seller_id":450662946,"shop_title":"嘟嘟家 酷风来袭","small_images":{"string":["https://img.alicdn.com/tfscom/i2/450662946/TB2WV.dpL1TBuNjy0FjXXajyXXa_!!450662946.jpg","https://img.alicdn.com/tfscom/i3/450662946/TB2toDQpH1YBuNjSszhXXcUsFXa_!!450662946.jpg","https://img.alicdn.com/tfscom/i4/450662946/TB2j6T2pQCWBuNjy0FaXXXUlXXa_!!450662946.jpg","https://img.alicdn.com/tfscom/i2/450662946/TB2FuGihOOYBuNjSsD4XXbSkFXa_!!450662946.jpg"]},"status":1,"title":"半身牛仔裙女2018新款夏季韩版宽松百搭学生BF风潮ins超火的裙子","tk_rate":"5.00","type":1,"user_type":0,"volume":89,"zk_final_price":"109.80","zk_final_price_wap":"109.80"},{"category":16,"click_url":"https://s.click.taobao.com/t?e=m%3D2%26s%3D1pgEMyGO8blw4vFB6t2Z2ueEDrYVVa64XoO8tOebS%2Bfjf2vlNIV67nKx%2F0WMtCwsjGYPrSmetxH9VCSQqTLsa4%2BDpQeWfDJaVpEUn89CVjnJsAA91U3vce%2FBas0tvb4eZz42eVlqqJT6BXppXS5x5z0BDlc5vrJjopr%2FSerwmYM1LTXXCD%2BOUvsQkLppJOqGUgJOt%2FgUtXY4GU9PM8GyritwjvUPA%2BzkcSpj5qSCmbA%3D","coupon_click_url":"https://uland.taobao.com/coupon/edetail?e=axaQcZXDXDAGQASttHIRqelATBH1eoytSuNX%2F0cyFv6Pr5ljijO76C2hIi8KRT8qiiDmULtsMvCJI6EXzi0xFL9fwBwwUiqlCfDTD%2F74gDLJnadaiBmiH%2FSs4zOlZ4se","coupon_end_time":"2018-05-30","coupon_info":"满200元减30元","coupon_remain_count":2150,"coupon_start_time":"2018-05-24","coupon_total_count":5000,"event_end_time":"1970-01-01 00:00:00","event_start_time":"1970-01-01 00:00:00","item_url":"http://h5.m.taobao.com/awp/core/detail.htm?id=569079538463","nick":"yueliang1985415","num_iid":569079538463,"pict_url":"https://img.alicdn.com/tfscom/i2/TB1M0zRpv9TBuNjy1zbYXFpepXa_M2.SS2","provcity":"广东 深圳","reserve_price":"538.00","seller_id":87253698,"shop_title":"s秀名媛馆 高端女装","small_images":{"string":["https://img.alicdn.com/tfscom/i1/TB1PfxfpStYBeNjSspkYXHU8VXa_M2.SS2","https://img.alicdn.com/tfscom/i7/TB1ptDRpv9TBuNjy1zbYXFpepXa_M2.SS2","https://img.alicdn.com/tfscom/i7/TB1QQ6XpwmTBuNjy1XbYXGMrVXa_M2.SS2","https://img.alicdn.com/tfscom/i3/TB1e1bQpv5TBuNjSspcYXHnGFXa_M2.SS2"]},"status":1,"title":"s秀2018夏女新款时尚港风ins超火T恤中长款蓬蓬网纱裙套装两件套","tk_rate":"15.00","type":1,"user_type":0,"volume":9,"zk_final_price":"269.00","zk_final_price_wap":"269.00"},{"category":16,"click_url":"https://s.click.taobao.com/t?e=m%3D2%26s%3Di%2FBrGRTeS91w4vFB6t2Z2ueEDrYVVa64XoO8tOebS%2Bfjf2vlNIV67nKx%2F0WMtCwsjGYPrSmetxH9VCSQqTLsa4%2BDpQeWfDJaVpEUn89CVjnJsAA91U3vce%2FBas0tvb4eZz42eVlqqJT6BXppXS5x5z0BDlc5vrJjopr%2FSerwmYOsSowblonTuNBI2Mmq9AhlJIVU%2B7iDh6VxwM1syVBzrB9hW2JKu7YsDJbuZDCrHt4%3D","coupon_click_url":"https://uland.taobao.com/coupon/edetail?e=BFcTFUzIkqMGQASttHIRqbWqjL2%2FMu%2BcS85%2BAekcBQyPr5ljijO76C2hIi8KRT8qiiDmULtsMvCJI6EXzi0xFL9fwBwwUiqlCfDTD%2F74gDLJnadaiBmiH%2FSs4zOlZ4se","coupon_end_time":"2018-05-31","coupon_info":"满100元减10元","coupon_remain_count":9211,"coupon_start_time":"2018-05-28","coupon_total_count":10000,"event_end_time":"1970-01-01 00:00:00","event_start_time":"1970-01-01 00:00:00","item_url":"http://h5.m.taobao.com/awp/core/detail.htm?id=569600285991","nick":"ericsha0007","num_iid":569600285991,"pict_url":"https://img.alicdn.com/tfscom/i3/2904804747/TB2xD5afOMnBKNjSZFzXXc_qVXa_!!2904804747.jpg","provcity":"北京","reserve_price":"219.00","seller_id":2904804747,"shop_title":"胡月明 AMARIS HOO","small_images":{"string":["https://img.alicdn.com/tfscom/i4/2904804747/TB2.ieyi98YBeNkSnb4XXaevFXa_!!2904804747.jpg","https://img.alicdn.com/tfscom/i3/2904804747/TB2pB6OrbSYBuNjSspfXXcZCpXa_!!2904804747.jpg","https://img.alicdn.com/tfscom/i3/2904804747/TB28dnBrb9YBuNjy0FgXXcxcXXa_!!2904804747.jpg","https://img.alicdn.com/tfscom/i2/2904804747/TB24R_Wrf1TBuNjy0FjXXajyXXa_!!2904804747.jpg"]},"status":1,"title":"大月月定制 连衣裙女夏2018新款露肩显瘦雪纺中长款ins超火的裙子","tk_rate":"5.00","type":1,"user_type":0,"volume":124,"zk_final_price":"169.00","zk_final_price_wap":"169.00"},{"category":16,"click_url":"https://s.click.taobao.com/t?e=m%3D2%26s%3Dy1u4cF%2FNJaVw4vFB6t2Z2ueEDrYVVa64yK8Cckff7TXjf2vlNIV67nKx%2F0WMtCwsjGYPrSmetxH9VCSQqTLsa4%2BDpQeWfDJaVpEUn89CVjnJsAA91U3vce%2FBas0tvb4eZz42eVlqqJT6BXppXS5x5z0BDlc5vrJjopr%2FSerwmYPdauuLewEf2KoSINHC3AbXjMTCuk80ROq0G5roL0JvhR9hW2JKu7YsDJbuZDCrHt4%3D","coupon_click_url":"https://uland.taobao.com/coupon/edetail?e=NwKW9uiRK4cGQASttHIRqfrywtHuKwTXzTlmBU7yF6GPr5ljijO76C2hIi8KRT8qiiDmULtsMvCJI6EXzi0xFL9fwBwwUiqlCfDTD%2F74gDLJnadaiBmiH%2FSs4zOlZ4se","coupon_end_time":"2018-06-10","coupon_info":"满99元减10元","coupon_remain_count":99720,"coupon_start_time":"2018-05-29","coupon_total_count":100000,"event_end_time":"1970-01-01 00:00:00","event_start_time":"1970-01-01 00:00:00","item_url":"http://h5.m.taobao.com/awp/core/detail.htm?id=564944086098","nick":"韩都衣舍敏丽专卖店","num_iid":564944086098,"pict_url":"https://img.alicdn.com/tfscom/i4/1111900536/TB1iBEQt1uSBuNjSsplXXbe8pXa_!!0-item_pic.jpg","provcity":"山东 济南","reserve_price":"288.00","seller_id":1111900536,"shop_title":"韩都衣舍敏丽专卖店","small_images":{"string":["https://img.alicdn.com/tfscom/i4/263817957/TB2hdpbXiQnBKNjSZFmXXcApVXa-263817957.jpg","https://img.alicdn.com/tfscom/i1/263817957/TB2jvBbXbZnBKNjSZFKXXcGOVXa-263817957.jpg","https://img.alicdn.com/tfscom/i1/263817957/TB2gWlWXiCYBuNkSnaVXXcMsVXa-263817957.jpg","https://img.alicdn.com/tfscom/i2/263817957/TB24grdXbSYBuNjSspiXXXNzpXa-263817957.jpg"]},"status":1,"title":"韩都衣舍2018女装夏装条纹收腰气质小清新短款美美的夏夏连衣裙","tk_rate":"6.51","type":1,"user_type":1,"volume":6,"zk_final_price":"165.00","zk_final_price_wap":"165.00"},{"category":16,"click_url":"https://s.click.taobao.com/t?e=m%3D2%26s%3Dprj2C0SXqqpw4vFB6t2Z2ueEDrYVVa64XoO8tOebS%2Bfjf2vlNIV67nKx%2F0WMtCwsjGYPrSmetxH9VCSQqTLsa4%2BDpQeWfDJaVpEUn89CVjnJsAA91U3vce%2FBas0tvb4eZz42eVlqqJT6BXppXS5x5z0BDlc5vrJjopr%2FSerwmYOCMHtpFwM8vWOcw86FTGy78rZl6sW6CV5IJ6G0ZTXBaytwjvUPA%2BzkcSpj5qSCmbA%3D","event_end_time":"1970-01-01 00:00:00","event_start_time":"1970-01-01 00:00:00","item_url":"http://h5.m.taobao.com/awp/core/detail.htm?id=565152848615","nick":"fengshengj","num_iid":565152848615,"pict_url":"https://img.alicdn.com/tfscom/i4/90489528/TB1_KncbuuSBuNjSsplXXbe8pXa_!!0-item_pic.jpg","provcity":"浙江 杭州","reserve_price":"299.00","seller_id":90489528,"shop_title":"日着設計師服飾品牌","small_images":{"string":["https://img.alicdn.com/tfscom/i4/90489528/TB2mKrcbuuSBuNjSsplXXbe8pXa_!!90489528.jpg","https://img.alicdn.com/tfscom/i4/90489528/TB2tOLpbv1TBuNjy0FjXXajyXXa_!!90489528.jpg","https://img.alicdn.com/tfscom/i3/90489528/TB2CsPmbpuWBuNjSspnXXX1NVXa_!!90489528.jpg","https://img.alicdn.com/tfscom/i4/90489528/TB2l92ebxSYBuNjSsphXXbGvVXa_!!90489528.jpg"]},"status":1,"title":"日着原创设计女装【你是407吗】2018夏季新款宽松不对称解构T恤","tk_rate":"5.00","type":1,"user_type":0,"volume":98,"zk_final_price":"299.00","zk_final_price_wap":"299.00"}]}
         * total_results : 5
         * request_id : 10fk4ls6lekjw
         */

        private ResultsBean results;
        private int total_results;
        private String request_id;

        public ResultsBean getResults() {
            return results;
        }

        public void setResults(ResultsBean results) {
            this.results = results;
        }

        public int getTotal_results() {
            return total_results;
        }

        public void setTotal_results(int total_results) {
            this.total_results = total_results;
        }

        public String getRequest_id() {
            return request_id;
        }

        public void setRequest_id(String request_id) {
            this.request_id = request_id;
        }

        public static class ResultsBean {
            private List<UatmTbkItemBean> uatm_tbk_item;

            public List<UatmTbkItemBean> getUatm_tbk_item() {
                return uatm_tbk_item;
            }

            public void setUatm_tbk_item(List<UatmTbkItemBean> uatm_tbk_item) {
                this.uatm_tbk_item = uatm_tbk_item;
            }

            public static class UatmTbkItemBean {
                /**
                 * category : 16
                 * click_url : https://s.click.taobao.com/t?e=m%3D2%26s%3D9eXo1%2B4wb0xw4vFB6t2Z2ueEDrYVVa64XoO8tOebS%2Bfjf2vlNIV67nKx%2F0WMtCwsjGYPrSmetxH9VCSQqTLsa4%2BDpQeWfDJaVpEUn89CVjnJsAA91U3vce%2FBas0tvb4eZz42eVlqqJT6BXppXS5x5z0BDlc5vrJjopr%2FSerwmYPPQZX9jO9tUbYtcWZSGtno5Zhxu%2BbPYAutNnoIVcZmJueY5tUZuWkpxgxdTc00KD8%3D
                 * coupon_click_url : https://uland.taobao.com/coupon/edetail?e=n7qaPzoNPcAGQASttHIRqQkZPCfQqsO4V1yHWHmoq9WPr5ljijO76C2hIi8KRT8qiiDmULtsMvCJI6EXzi0xFL9fwBwwUiqlCfDTD%2F74gDLJnadaiBmiH%2FSs4zOlZ4se
                 * coupon_end_time : 2018-06-30
                 * coupon_info : 满100元减10元
                 * coupon_remain_count : 98688
                 * coupon_start_time : 2018-05-26
                 * coupon_total_count : 100000
                 * event_end_time : 1970-01-01 00:00:00
                 * event_start_time : 1970-01-01 00:00:00
                 * item_url : http://h5.m.taobao.com/awp/core/detail.htm?id=569092747231
                 * nick : du嘟嘟家
                 * num_iid : 569092747231
                 * pict_url : https://img.alicdn.com/tfscom/i4/450662946/TB2FCOfhsyYBuNkSnfoXXcWgVXa_!!450662946.jpg
                 * provcity : 广东 广州
                 * reserve_price : 109.80
                 * seller_id : 450662946
                 * shop_title : 嘟嘟家 酷风来袭
                 * small_images : {"string":["https://img.alicdn.com/tfscom/i2/450662946/TB2WV.dpL1TBuNjy0FjXXajyXXa_!!450662946.jpg","https://img.alicdn.com/tfscom/i3/450662946/TB2toDQpH1YBuNjSszhXXcUsFXa_!!450662946.jpg","https://img.alicdn.com/tfscom/i4/450662946/TB2j6T2pQCWBuNjy0FaXXXUlXXa_!!450662946.jpg","https://img.alicdn.com/tfscom/i2/450662946/TB2FuGihOOYBuNjSsD4XXbSkFXa_!!450662946.jpg"]}
                 * status : 1
                 * title : 半身牛仔裙女2018新款夏季韩版宽松百搭学生BF风潮ins超火的裙子
                 * tk_rate : 5.00
                 * type : 1
                 * user_type : 0
                 * volume : 89
                 * zk_final_price : 109.80
                 * zk_final_price_wap : 109.80
                 */

                private int category;
                private String click_url;
                private String coupon_click_url;
                private String coupon_end_time;
                private String coupon_info;
                private int coupon_remain_count;
                private String coupon_start_time;
                private int coupon_total_count;
                private String event_end_time;
                private String event_start_time;
                private String item_url;
                private String nick;
                private long num_iid;
                private String pict_url;
                private String provcity;
                private String reserve_price;
                private long seller_id;
                private String shop_title;
                private SmallImagesBean small_images;
                private int status;
                private String title;
                private String tk_rate;
                private int type;
                private int user_type;
                private int volume;
                private String zk_final_price;
                private String zk_final_price_wap;

                public int getCategory() {
                    return category;
                }

                public void setCategory(int category) {
                    this.category = category;
                }

                public String getClick_url() {
                    return click_url;
                }

                public void setClick_url(String click_url) {
                    this.click_url = click_url;
                }

                public String getCoupon_click_url() {
                    return coupon_click_url;
                }

                public void setCoupon_click_url(String coupon_click_url) {
                    this.coupon_click_url = coupon_click_url;
                }

                public String getCoupon_end_time() {
                    return coupon_end_time;
                }

                public void setCoupon_end_time(String coupon_end_time) {
                    this.coupon_end_time = coupon_end_time;
                }

                public String getCoupon_info() {
                    return coupon_info;
                }

                public void setCoupon_info(String coupon_info) {
                    this.coupon_info = coupon_info;
                }

                public int getCoupon_remain_count() {
                    return coupon_remain_count;
                }

                public void setCoupon_remain_count(int coupon_remain_count) {
                    this.coupon_remain_count = coupon_remain_count;
                }

                public String getCoupon_start_time() {
                    return coupon_start_time;
                }

                public void setCoupon_start_time(String coupon_start_time) {
                    this.coupon_start_time = coupon_start_time;
                }

                public int getCoupon_total_count() {
                    return coupon_total_count;
                }

                public void setCoupon_total_count(int coupon_total_count) {
                    this.coupon_total_count = coupon_total_count;
                }

                public String getEvent_end_time() {
                    return event_end_time;
                }

                public void setEvent_end_time(String event_end_time) {
                    this.event_end_time = event_end_time;
                }

                public String getEvent_start_time() {
                    return event_start_time;
                }

                public void setEvent_start_time(String event_start_time) {
                    this.event_start_time = event_start_time;
                }

                public String getItem_url() {
                    return item_url;
                }

                public void setItem_url(String item_url) {
                    this.item_url = item_url;
                }

                public String getNick() {
                    return nick;
                }

                public void setNick(String nick) {
                    this.nick = nick;
                }

                public long getNum_iid() {
                    return num_iid;
                }

                public void setNum_iid(long num_iid) {
                    this.num_iid = num_iid;
                }

                public String getPict_url() {
                    return pict_url;
                }

                public void setPict_url(String pict_url) {
                    this.pict_url = pict_url;
                }

                public String getProvcity() {
                    return provcity;
                }

                public void setProvcity(String provcity) {
                    this.provcity = provcity;
                }

                public String getReserve_price() {
                    return reserve_price;
                }

                public void setReserve_price(String reserve_price) {
                    this.reserve_price = reserve_price;
                }

                public long getSeller_id() {
                    return seller_id;
                }

                public void setSeller_id(long seller_id) {
                    this.seller_id = seller_id;
                }

                public String getShop_title() {
                    return shop_title;
                }

                public void setShop_title(String shop_title) {
                    this.shop_title = shop_title;
                }

                public SmallImagesBean getSmall_images() {
                    return small_images;
                }

                public void setSmall_images(SmallImagesBean small_images) {
                    this.small_images = small_images;
                }

                public int getStatus() {
                    return status;
                }

                public void setStatus(int status) {
                    this.status = status;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getTk_rate() {
                    return tk_rate;
                }

                public void setTk_rate(String tk_rate) {
                    this.tk_rate = tk_rate;
                }

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }

                public int getUser_type() {
                    return user_type;
                }

                public void setUser_type(int user_type) {
                    this.user_type = user_type;
                }

                public int getVolume() {
                    return volume;
                }

                public void setVolume(int volume) {
                    this.volume = volume;
                }

                public String getZk_final_price() {
                    return zk_final_price;
                }

                public void setZk_final_price(String zk_final_price) {
                    this.zk_final_price = zk_final_price;
                }

                public String getZk_final_price_wap() {
                    return zk_final_price_wap;
                }

                public void setZk_final_price_wap(String zk_final_price_wap) {
                    this.zk_final_price_wap = zk_final_price_wap;
                }

                public static class SmallImagesBean {
                    private List<String> string;

                    public List<String> getString() {
                        return string;
                    }

                    public void setString(List<String> string) {
                        this.string = string;
                    }
                }
            }
        }
    }
}
