package com.youcoupon.john_li.youcouponshopping.YouActivity;

import android.os.Bundle;
import android.support.annotation.Nullable;

/**
 * Created by John_Li on 2019/9/12.
 */

public class TutorialAcitivity extends BaseActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initView();
        setListener();
        initData();
    }

    @Override
    public void initView() {

    }

    @Override
    public void setListener() {

    }

    @Override
    public void initData() {

    }
}
