package com.youcoupon.john_li.youcouponshopping;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ali.auth.third.core.model.User;
import com.gyf.immersionbar.ImmersionBar;
import com.youcoupon.john_li.youcouponshopping.YouActivity.BaseActivity;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.LogInListener;

/**
 * Created by John_Li on 2019/10/30.
 */

public class LoginActivity extends BaseActivity {
    private Button loginBtn;
    private EditText phoneEt, pwEt;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initImmersionBar();
        initView();
        setListener();
        initData();
    }

    public  void initImmersionBar() {
        ImmersionBar.with(this).titleBar(R.id.login_toolbar).keyboardEnable(true).init();
    }

    @Override
    public void initView() {
        loginBtn = findViewById(R.id.btn_login);
        phoneEt = findViewById(R.id.login_et_phone);
        pwEt = findViewById(R.id.login_et_phone);
    }

    @Override
    public void setListener() {
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = phoneEt.getText().toString();
                String pw = pwEt.getText().toString();
                if (phone != null && pw != null) {
                    callBombLogin(phone, pw);
                } else {
                    Toast.makeText(LoginActivity.this, "请填写账户密码！", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void callBombLogin(String phone, String pw) {
        //邮箱登录
        BmobUser.loginByAccount(phone,pw, new LogInListener<User>() {

            @Override
            public void done(User user, BmobException e) {
                if (e == null) {
                    Toast.makeText(LoginActivity.this, "登录成功！"+ user.toString(), Toast.LENGTH_LONG).show();
                } else {
                    Log.e("BMOB", e.toString());
                    Toast.makeText(LoginActivity.this, "登录失败！"+ e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public void initData() {

    }
}
