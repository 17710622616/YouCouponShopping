package com.youcoupon.john_li.youcouponshopping.YouActivity;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.youcoupon.john_li.youcouponshopping.R;

/**
 * Created by John_Li on 10/5/2018.
 */

public class LoginActivity extends BaseActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initView();
        setListener();
        initData();
    }

    @Override
    public void initView() {

    }

    @Override
    public void setListener() {

    }

    @Override
    public void initData() {

    }
}
