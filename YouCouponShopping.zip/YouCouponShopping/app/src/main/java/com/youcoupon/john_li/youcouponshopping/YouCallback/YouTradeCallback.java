package com.youcoupon.john_li.youcouponshopping.YouCallback;

/**
 * Created by John_Li on 21/5/2018.
 */

public class YouTradeCallback {
}
